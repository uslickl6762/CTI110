 # Lauren Uslick
 # 2/20/2024
 #P1HW1
 # Basic output with variables



user_num = int(input('Enter integer:\n'))
# Type your code here
print("You entered:",user_num)
print(user_num,"squared is",user_num*user_num)
print("And",user_num,"cubed is",user_num*user_num*user_num,"!!")
a_num = int(input('Enter another integer:\n'))
print(user_num,"+",a_num,"is",user_num+a_num)
print(user_num,"*",a_num,"is",user_num*a_num)
